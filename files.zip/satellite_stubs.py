"""
satellite_stubs.py — МОК-заглушки VPN- и AI-сателлитов.

Это НЕ рабочая интеграция с 3X-UI / OpenAI / Anthropic / Google API.
Реальный реселлинг доступа к LLM API через промокоды, как правило,
нарушает условия использования провайдеров, а массовая выдача
VPN-подписок как коммерческий сервис требует отдельной юридической
проверки. Здесь только имитация ответа для демонстрации потока данных.
"""

from dataclasses import dataclass


@dataclass
class MockVPNResult:
    vless_link: str
    expire_note: str


@dataclass
class MockAIResult:
    grant_note: str


def issue_mock_vpn_key(reward_value: str) -> MockVPNResult:
    fake_uuid = "00000000-0000-0000-0000-000000000000"
    return MockVPNResult(
        vless_link=f"vless://{fake_uuid}@mock.example:443?security=reality#DEMO",
        expire_note=f"[MOCK] Условная выдача по промокоду: {reward_value}",
    )


def issue_mock_ai_grant(reward_value: str) -> MockAIResult:
    return MockAIResult(
        grant_note=f"[MOCK] Условное начисление доступа: {reward_value}. "
        f"Реальная выдача доступа к сторонним LLM API не реализована."
    )
