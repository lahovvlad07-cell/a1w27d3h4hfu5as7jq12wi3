"""
cases.py — механика кейсов (честная рулетка на secrets.SystemRandom, т.е. CSPRNG).

Здесь описаны 4 кейса из ТЗ. Промокоды генерируются как ЗАГЛУШКИ
(mock_stub.py) — реальная выдача VPN-ключей / AI-токенов не производится.
"""

import secrets
import uuid
from dataclasses import dataclass

_rng = secrets.SystemRandom()


@dataclass
class Prize:
    label: str
    weight: float
    service_type: str   # 'vpn' | 'ai' | 'points'
    reward_value: str
    is_free_tier: bool = False


CASES: dict[str, dict] = {
    "vpn_box": {
        "title": "VPN-Box",
        "price": 40,
        "prizes": [
            Prize("Подписка 1 месяц (безлимит)", 60, "vpn", "30_days"),
            Prize("Подписка 3 месяца (безлимит)", 30, "vpn", "90_days"),
            Prize("Подписка 6 месяцев (безлимит)", 9, "vpn", "180_days"),
            Prize("Подписка 12 месяцев (безлимит)", 1, "vpn", "365_days"),
        ],
    },
    "ai_box": {
        "title": "AI & Neural Box",
        "price": 50,
        "prizes": [
            Prize("100 000 токенов (все модели)", 55, "ai", "100000_tokens"),
            Prize("300 000 токенов + доступ к топ-модели", 30, "ai", "300000_tokens_top"),
            Prize("Безлимит на 1 месяц (rate-limited)", 12, "ai", "unlimited_30_days"),
            Prize("VIP-безлимит на 3 месяца", 3, "ai", "vip_unlimited_90_days"),
        ],
    },
    "points_booster": {
        "title": "Points Booster",
        "price": 30,
        "prizes": [
            Prize("15 поинтов", 45, "points", "15"),
            Prize("25 поинтов", 35, "points", "25"),
            Prize("45 поинтов", 15, "points", "45"),
            Prize("100 поинтов", 4.5, "points", "100"),
            Prize("300 поинтов (джекпот)", 0.5, "points", "300"),
        ],
    },
    "free_box": {
        "title": "Daily / Weekly Free Box",
        "price": 0,
        "prizes": [
            Prize("VPN-тест: 1 день / 2 ГБ", 70, "vpn", "1_day_2gb", is_free_tier=True),
            Prize("AI-тест: 5-10 запросов (лёгкие модели)", 20, "ai", "5_10_requests_light", is_free_tier=True),
            Prize("5-10 поинтов", 9.9, "points", "5"),
            Prize("VPN-подписка 1 месяц (маркетинг. джекпот)", 0.1, "vpn", "30_days", is_free_tier=True),
        ],
    },
}


def roll_case(case_key: str) -> Prize:
    case = CASES[case_key]
    prizes: list[Prize] = case["prizes"]
    total_weight = sum(p.weight for p in prizes)
    roll = _rng.uniform(0, total_weight)
    cumulative = 0.0
    for prize in prizes:
        cumulative += prize.weight
        if roll <= cumulative:
            return prize
    return prizes[-1]  # fallback safety net


def generate_promocode() -> str:
    """Генерирует непредсказуемый код через CSPRNG (не для продакшн-выдачи реальных услуг)."""
    return uuid.UUID(bytes=secrets.token_bytes(16)).hex[:12].upper()
