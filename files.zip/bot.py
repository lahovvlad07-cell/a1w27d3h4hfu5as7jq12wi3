"""
bot.py — прототип «Главного Кейс-Бота» на aiogram 3.x.

Запуск:
    export BOT_TOKEN=xxxx:yyyy   # токен от @BotFather
    pip install -r requirements.txt
    python bot.py

Что реализовано (демо):
    - /start — регистрация, учёт реферала, принятие пользовательского соглашения
    - /balance — баланс поинтов
    - /addpoints_debug <n> — ТЕСТОВОЕ пополнение баланса (заменить на реальный платёжный шлюз)
    - /cases — список кейсов inline-кнопками
    - открытие кейса — списание поинтов, честный ролл через CSPRNG, лог, мок-выдача награды
    - /freebox — бесплатный кейс с cooldown 7 дней (антифрод)

Что НЕ реализовано (сознательно, см. предупреждения в ответе):
    - Реальные платежи (Telegram Stars / фиат-эквайринг)
    - Реальная интеграция с 3X-UI / Marzban (выдача VLESS)
    - Реальная интеграция с OpenAI/Anthropic/Google API (реселлинг доступа)
    - Проверка "аккаунт старше N дней" / капча (анти-бот)
"""

import asyncio
import logging
import os

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

import db
import cases
from satellite_stubs import issue_mock_vpn_key, issue_mock_ai_grant

logging.basicConfig(level=logging.INFO)

TERMS_TEXT = (
    "Пользовательское соглашение (демо-версия)\n\n"
    "Поинты являются виртуальными единицами внутри сервиса, не имеют денежной "
    "стоимости, не подлежат обмену на наличные средства или криптовалюту и не "
    "выводятся за пределы системы. Прокрутка кейсов — активация механики "
    "распределения цифровых услуг между пользователями.\n\n"
    "Нажимая «Принять», вы подтверждаете согласие с условиями."
)


def terms_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="Принять", callback_data="accept_terms")]]
    )


def cases_keyboard() -> InlineKeyboardMarkup:
    buttons = []
    for key, case in cases.CASES.items():
        if key == "free_box":
            continue
        buttons.append(
            [InlineKeyboardButton(
                text=f"{case['title']} — {case['price']} пт",
                callback_data=f"open:{key}",
            )]
        )
    return InlineKeyboardMarkup(inline_keyboard=buttons)


async def main():
    token = os.environ.get("BOT_TOKEN")
    if not token:
        raise RuntimeError("Установите переменную окружения BOT_TOKEN")

    db.init_db()
    bot = Bot(token=token)
    dp = Dispatcher()

    @dp.message(CommandStart())
    async def start_handler(message: Message):
        args = message.text.split(maxsplit=1)
        referrer_id = None
        if len(args) > 1 and args[1].startswith("ref"):
            try:
                referrer_id = int(args[1].replace("ref", ""))
            except ValueError:
                referrer_id = None

        user = db.get_or_create_user(
            message.from_user.id, message.from_user.username, referrer_id
        )
        if not user["accepted_terms"]:
            await message.answer(TERMS_TEXT, reply_markup=terms_keyboard())
        else:
            await message.answer(
                f"С возвращением! Баланс: {db.get_balance(message.from_user.id)} поинтов.\n"
                f"Команды: /balance /cases /freebox"
            )

    @dp.callback_query(F.data == "accept_terms")
    async def accept_terms_handler(callback: CallbackQuery):
        db.accept_terms(callback.from_user.id)
        await callback.message.edit_text(
            "Спасибо! Соглашение принято.\nКоманды: /balance /cases /freebox"
        )
        await callback.answer()

    @dp.message(Command("balance"))
    async def balance_handler(message: Message):
        bal = db.get_balance(message.from_user.id)
        await message.answer(f"Ваш баланс: {bal} поинтов.")

    @dp.message(Command("addpoints_debug"))
    async def addpoints_debug_handler(message: Message):
        # ТОЛЬКО ДЛЯ ЛОКАЛЬНОГО ТЕСТИРОВАНИЯ. Уберите перед любым реальным использованием.
        parts = message.text.split()
        amount = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 100
        db.add_points(message.from_user.id, amount)
        await message.answer(f"[DEBUG] Начислено {amount} поинтов.")

    @dp.message(Command("cases"))
    async def cases_handler(message: Message):
        await message.answer("Доступные кейсы:", reply_markup=cases_keyboard())

    @dp.message(Command("freebox"))
    async def freebox_handler(message: Message):
        user_id = message.from_user.id
        ok, reason = db.can_open_free_case(user_id)
        if not ok:
            await message.answer(f"⏳ {reason}")
            return
        prize = cases.roll_case("free_box")
        db.mark_free_case_opened(user_id)
        await _grant_prize(message, user_id, "free_box", prize)

    @dp.callback_query(F.data.startswith("open:"))
    async def open_case_handler(callback: CallbackQuery):
        case_key = callback.data.split(":", 1)[1]
        case = cases.CASES[case_key]
        user_id = callback.from_user.id

        if not db.spend_points(user_id, case["price"]):
            await callback.answer("Недостаточно поинтов.", show_alert=True)
            return

        prize = cases.roll_case(case_key)
        await callback.answer()
        await _grant_prize(callback.message, user_id, case_key, prize, as_new_message=True)

    async def _grant_prize(message: Message, user_id: int, case_key: str, prize, as_new_message=False):
        promocode = cases.generate_promocode() if prize.service_type != "points" else None
        db.log_case_open(user_id, case_key, prize.label, promocode)

        if prize.service_type == "points":
            db.add_points(user_id, int(prize.reward_value))
            text = f"🎉 Выпало: {prize.label}\nНачислено на баланс."
        elif prize.service_type == "vpn":
            mock = issue_mock_vpn_key(prize.reward_value)
            text = f"🎉 Выпало: {prize.label}\n{mock.expire_note}\n(демо-ссылка: {mock.vless_link})"
        else:  # 'ai'
            mock = issue_mock_ai_grant(prize.reward_value)
            text = f"🎉 Выпало: {prize.label}\n{mock.grant_note}"

        if as_new_message:
            await message.answer(text)
        else:
            await message.answer(text)

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
