"""
db.py — слой работы с базой данных для прототипа Кейс-Бота.

ВАЖНО: это учебный/демонстрационный прототип.
- Платежи (Stars / фиат-эквайринг) НЕ реализованы — баланс пополняется
  вручную командой /addpoints_debug (только для теста).
- VPN- и AI-сателлиты — заглушки (mock), реальных ключей/токенов не выдают.
- Реализуйте реальную выдачу промокодов/интеграции самостоятельно, предварительно
  проверив соответствие ToS провайдеров (Anthropic, OpenAI, Google) и локальному
  законодательству о лотереях/азартных играх.
"""

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta

DB_PATH = "case_bot.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    telegram_id INTEGER PRIMARY KEY,
    username TEXT,
    points_balance INTEGER DEFAULT 0,
    referrer_id INTEGER REFERENCES users(telegram_id),
    accepted_terms INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS promocodes (
    code TEXT PRIMARY KEY,
    service_type TEXT,       -- 'vpn' | 'ai' | 'points'
    reward_value TEXT,       -- e.g. '30_days', '100000_tokens', '50_points'
    is_free_tier INTEGER DEFAULT 0,
    is_used INTEGER DEFAULT 0,
    activated_by INTEGER REFERENCES users(telegram_id),
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS free_case_cooldowns (
    telegram_id INTEGER PRIMARY KEY REFERENCES users(telegram_id),
    last_opened_at TEXT,
    free_activations_this_month INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS case_open_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER REFERENCES users(telegram_id),
    case_key TEXT,
    prize_label TEXT,
    promocode TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.executescript(SCHEMA)


def get_or_create_user(telegram_id: int, username: str | None, referrer_id: int | None = None):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        if row:
            return dict(row)
        conn.execute(
            "INSERT INTO users (telegram_id, username, referrer_id) VALUES (?, ?, ?)",
            (telegram_id, username, referrer_id),
        )
        row = conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        return dict(row)


def accept_terms(telegram_id: int):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET accepted_terms = 1 WHERE telegram_id = ?", (telegram_id,)
        )


def get_balance(telegram_id: int) -> int:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT points_balance FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        return row["points_balance"] if row else 0


def add_points(telegram_id: int, amount: int):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET points_balance = points_balance + ? WHERE telegram_id = ?",
            (amount, telegram_id),
        )


def spend_points(telegram_id: int, amount: int) -> bool:
    """Atomically deduct points if balance is sufficient. Returns success flag."""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT points_balance FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        if not row or row["points_balance"] < amount:
            return False
        conn.execute(
            "UPDATE users SET points_balance = points_balance - ? WHERE telegram_id = ?",
            (amount, telegram_id),
        )
        return True


def log_case_open(telegram_id: int, case_key: str, prize_label: str, promocode: str | None):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO case_open_log (telegram_id, case_key, prize_label, promocode) "
            "VALUES (?, ?, ?, ?)",
            (telegram_id, case_key, prize_label, promocode),
        )


def can_open_free_case(telegram_id: int) -> tuple[bool, str]:
    """Anti-fraud: 1 free case per 7 days per telegram_id."""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM free_case_cooldowns WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        if not row or not row["last_opened_at"]:
            return True, ""
        last = datetime.fromisoformat(row["last_opened_at"])
        if datetime.utcnow() - last >= timedelta(days=7):
            return True, ""
        remaining = timedelta(days=7) - (datetime.utcnow() - last)
        hours = int(remaining.total_seconds() // 3600)
        return False, f"Следующий бесплатный кейс будет доступен через ~{hours} ч."


def mark_free_case_opened(telegram_id: int):
    with get_conn() as conn:
        exists = conn.execute(
            "SELECT 1 FROM free_case_cooldowns WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        now = datetime.utcnow().isoformat()
        if exists:
            conn.execute(
                "UPDATE free_case_cooldowns SET last_opened_at = ?, "
                "free_activations_this_month = free_activations_this_month + 1 "
                "WHERE telegram_id = ?",
                (now, telegram_id),
            )
        else:
            conn.execute(
                "INSERT INTO free_case_cooldowns (telegram_id, last_opened_at, "
                "free_activations_this_month) VALUES (?, ?, 1)",
                (telegram_id, now),
            )


def create_promocode(code: str, service_type: str, reward_value: str, is_free_tier: bool = False):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO promocodes (code, service_type, reward_value, is_free_tier) "
            "VALUES (?, ?, ?, ?)",
            (code, service_type, reward_value, int(is_free_tier)),
        )
